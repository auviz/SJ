//
//  OTRDataTransfer.m
//  ServerlessDemo
//
//  Created by Christopher Ballinger on 5/27/14.
//
//

#import "OTRDataTransfer.h"

@implementation OTRDataTransfer

@end
