### CPAProxyDependencies build scripts

These shell scripts build depencencies for CPAProxy, namely __openssl__, __libevent__ and __Tor__. The results are static library files that are needed by CPAProxy to start a Tor proces, a header file __tor_cpaproxy.h__ and the resource files __torrc__ and __geoip__.
