### OTRKitDependencies build scripts

These shell scripts build depencencies for OTRKit, namely __libgpg-error__, __libgcrypt__ and __libotr__.
