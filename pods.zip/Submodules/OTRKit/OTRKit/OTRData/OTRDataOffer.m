//
//  OTRDataOffer.m
//  ServerlessDemo
//
//  Created by Christopher Ballinger on 5/27/14.
//
//

#import "OTRDataOffer.h"

@implementation OTRDataOffer

@end
