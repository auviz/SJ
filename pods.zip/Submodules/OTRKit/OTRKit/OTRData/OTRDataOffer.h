//
//  OTRDataOffer.h
//  ServerlessDemo
//
//  Created by Christopher Ballinger on 5/27/14.
//
//

#import <Foundation/Foundation.h>

@interface OTRDataOffer : NSObject

@end
